import java.util.Scanner;

/**
 * Main.java
 * Entry point for the ChatApp application.
 */
public class Main {

    // FIX: track total messages sent across menu loops so message numbers
    // (and therefore hashes) are never duplicated between sessions.
    private static int totalMessagesSent = 0;

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Login   login   = new Login();

        System.out.println("=============================");
        System.out.println("      Welcome to QuickChat   ");
        System.out.println("=============================\n");

        // ── REGISTRATION ─────────────────────────────────────────────────────
        System.out.println("--- Registration ---");

        System.out.print("Enter first name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter last name: ");
        String lastName = scanner.nextLine();

        String username;
        while (true) {
            System.out.print("Enter username (max 5 chars, must contain _): ");
            username = scanner.nextLine();
            if (login.checkUserName(username)) {
                System.out.println("Username successfully captured.");
                break;
            }
            System.out.println("Username is not correctly formatted, please ensure that your username "
                    + "contains an underscore and is no more than five characters in length.");
        }

        String password;
        while (true) {
            System.out.print("Enter password (min 8 chars, 1 capital, 1 number, 1 special): ");
            password = scanner.nextLine();
            if (login.checkPasswordComplexity(password)) {
                System.out.println("Password successfully captured.");
                break;
            }
            System.out.println("Password is not correctly formatted, please ensure that the password "
                    + "contains at least eight characters, a capital letter, a number and a special character.");
        }

        String cellNumber;
        while (true) {
            System.out.print("Enter cell phone number (international format e.g. +27831234567): ");
            cellNumber = scanner.nextLine();
            String cellResult = Login.checkCellPhoneNumber(cellNumber);
            System.out.println(cellResult);
            if (cellResult.equals("Cell phone number successfully captured.")) {
                break;
            }
        }

        // FIX: original Login had no constructor that accepted firstName/lastName.
        // Login now has a 5-arg constructor; re-create the object with all fields.
        login = new Login(username, password, firstName, lastName, cellNumber);
        System.out.println(login.registerUser(username, password));

        // ── LOGIN ─────────────────────────────────────────────────────────────
        System.out.println("\n--- Login ---");
        while (true) {
            System.out.print("Enter username: ");
            String enteredUser = scanner.nextLine();
            System.out.print("Enter password: ");
            String enteredPass = scanner.nextLine();

            // FIX: original loginUser() returned boolean; it now returns a String.
            String loginResult = login.loginUser(enteredUser, enteredPass);
            System.out.println(loginResult);

            if (loginResult.startsWith("Welcome")) {
                break;
            }
        }

        // ── LOAD STORED MESSAGES ──────────────────────────────────────────────
        Message.loadStoredMessages();

        // ── MAIN MENU LOOP ────────────────────────────────────────────────────
        boolean running = true;
        while (running) {
            System.out.println("\n=============================");
            System.out.println("           Main Menu         ");
            System.out.println("=============================");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.println("4) Stored Messages");
            System.out.print("Enter choice: ");

            int choice;
            try {
                choice = Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a number between 1 and 4.");
                continue;
            }

            switch (choice) {
                case 1:
                    sendMessages(scanner);
                    break;
                case 2:
                    System.out.println(Message.printMessages());
                    break;
                case 3:
                    System.out.println("\nGoodbye!");
                    running = false;
                    break;
                case 4:
                    storedMessagesMenu(scanner);
                    break;
                default:
                    System.out.println("Invalid option. Please enter 1, 2, 3, or 4.");
            }
        }

        scanner.close();
    }

    // ── SEND MESSAGES ────────────────────────────────────────────────────────
    private static void sendMessages(Scanner scanner) {
        System.out.print("\nHow many messages would you like to send? ");
        int numMessages;
        try {
            numMessages = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Invalid number. Returning to menu.");
            return;
        }

        for (int i = 1; i <= numMessages; i++) {
            // FIX: use a global counter so messageNumber is unique across
            // multiple calls to sendMessages(), preventing duplicate hashes.
            totalMessagesSent++;
            System.out.println("\n--- Message " + totalMessagesSent + " ---");
            Message message = new Message(totalMessagesSent);

            // Recipient
            while (true) {
                System.out.print("Enter recipient cell number: ");
                String recipient = scanner.nextLine();
                String recipResult = message.checkRecipientCell(recipient);
                System.out.println(recipResult);
                if (recipResult.equals("Cell phone number successfully captured.")) {
                    message.setRecipient(recipient);
                    break;
                }
            }

            // Message text
            while (true) {
                System.out.print("Enter message text (max 250 chars): ");
                String text = scanner.nextLine();
                String lengthResult = message.checkMessageLength(text);
                System.out.println(lengthResult);
                if (lengthResult.equals("Message ready to send.")) {
                    message.setMessageText(text);
                    break;
                }
            }

            // Hash and ID
            String hash = message.createMessageHash();
            System.out.println("Message Hash : " + hash);
            System.out.println("Message ID   : " + message.getMessageID());

            // User chooses action
            String action = message.sentMessage();
            System.out.println(action);
        }

        System.out.println("\n--- Session Summary ---");
        System.out.println("Sent        : " + Message.getSentMessages().size());
        System.out.println("Stored      : " + Message.getStoredMessages().size());
        System.out.println("Disregarded : " + Message.getDisregardedMessages().size());
    }

    // ── STORED MESSAGES SUB-MENU ─────────────────────────────────────────────
    private static void storedMessagesMenu(Scanner scanner) {
        Message helper    = new Message();
        boolean inSubMenu = true;

        while (inSubMenu) {
            System.out.println("\n--- Stored Messages ---");
            System.out.println("a) Display all stored messages");
            System.out.println("b) Display longest message");
            System.out.println("c) Search by message ID");
            System.out.println("d) Search by recipient");
            System.out.println("e) Delete by message hash");
            System.out.println("f) Display full report");
            System.out.println("g) Return to main menu");
            System.out.print("Enter choice: ");

            String input = scanner.nextLine().trim().toLowerCase();

            switch (input) {
                case "a":
                    displayAllStoredMessages();
                    break;
                case "b":
                    String longest = helper.displayLongestMessage();
                    if (longest.isEmpty()) {
                        System.out.println("No stored messages available.");
                    } else {
                        System.out.println("\nLongest message:\n" + longest);
                    }
                    break;
                case "c":
                    System.out.print("Enter message ID to search: ");
                    System.out.println(helper.searchByMessageID(scanner.nextLine().trim()));
                    break;
                case "d":
                    System.out.print("Enter recipient number to search: ");
                    System.out.println(helper.searchByRecipient(scanner.nextLine().trim()));
                    break;
                case "e":
                    System.out.print("Enter message hash to delete: ");
                    System.out.println(helper.deleteByHash(scanner.nextLine().trim()));
                    break;
                case "f":
                    System.out.println(Message.printMessages());
                    break;
                case "g":
                    inSubMenu = false;
                    break;
                default:
                    System.out.println("Invalid option. Please enter a letter from a to g.");
            }
        }
    }

    // ── DISPLAY ALL STORED MESSAGES ──────────────────────────────────────────
    private static void displayAllStoredMessages() {
        java.util.List<String> stored = Message.getStoredMessages();
        if (stored.isEmpty()) {
            System.out.println("No stored messages loaded.");
            return;
        }
        System.out.println("\n--- All Stored Messages ---");
        for (int i = 0; i < stored.size(); i++) {
            System.out.println((i + 1) + ". " + stored.get(i));
        }
    }
}
