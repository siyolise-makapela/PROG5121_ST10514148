import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * MessageTest.java
 * JUnit 4 tests for the Message class.
 * Place this file in src/test/java (Test Packages in NetBeans).
 *
 * ── Part 2 test data ──────────────────────────────────────────
 *   Message 1 → number: 1, recipient: +27718693002
 *               text: "Hi Mike, can you join us for dinner tonight?"
 *               hash ends with: :0:HITONIGHT
 *
 *   Message 2 → number: 2, recipient: 08575975889 (invalid – no international code)
 *               text: "Hi Keegan, did you receive the payment?"
 *
 * ── Part 3 test data ──────────────────────────────────────────
 *   Message 1 → recipient: +27834557896  text: "Did you get the cake?"            action: Send
 *   Message 2 → recipient: +27838884567  text: "Where are you? You are late! I have asked you to be on time."  action: Send
 *   Message 3 → recipient: +27834484567  text: "How are you doing?"               action: Disregard
 *   Message 4 → recipient: 0838884567    text: "It is dinner time!"               action: Send
 *   Message 5 → recipient: +27838884567  text: "Ok, I am leaving without you."    action: Send
 */
public class MessageTest {

    // ══════════════════════════════════════════════
    // FIELDS
    // ══════════════════════════════════════════════

    private Message message1;
    private Message message2;

    // ══════════════════════════════════════════════
    // TESTABLE MESSAGE – inner helper class
    // Overrides sentMessage() to avoid real Scanner input.
    // Calls processMessageAction() so the static arrays
    // are populated exactly as they would be in the real app.
    // ══════════════════════════════════════════════

    private static class TestableMessage extends Message {

        private final int simulatedOption;

        public TestableMessage(int messageNumber, int simulatedOption) {
            super(messageNumber);
            this.simulatedOption = simulatedOption;
        }

        @Override
        public String sentMessage() {
            // Populate arrays just as the real sentMessage() would
            processMessageAction(simulatedOption);
            switch (simulatedOption) {
                case 1: return "Message successfully sent.";
                case 2: return "Press 0 to delete the message.";
                case 3: return "Message successfully stored.";
                default: return "Invalid option selected.";
            }
        }
    }

    // ══════════════════════════════════════════════
    // @Before – runs before EVERY test
    // ══════════════════════════════════════════════

    /**
     * Clears all static arrays and creates fresh Part 2 test objects.
     * This prevents one test from interfering with another.
     */
    @Before
    public void setUp() {
        // Reset all static arrays so every test starts clean
        Message.clearAllArrays();

        // Part 2 test objects
        message1 = new Message(1);
        message1.setRecipient("+27718693002");
        message1.setMessageText("Hi Mike, can you join us for dinner tonight?");

        message2 = new Message(2);
        message2.setRecipient("08575975889");
        message2.setMessageText("Hi Keegan, did you receive the payment?");
    }

    // ══════════════════════════════════════════════
    // ── PART 2 TESTS (unchanged) ──────────────────
    // ══════════════════════════════════════════════

    // ── Message length ────────────────────────────

    @Test
    public void testCheckMessageLength_validMessage_returnsSuccess() {
        String result = message1.checkMessageLength(message1.getMessageText());
        assertEquals("Message ready to send.", result);
    }

    @Test
    public void testCheckMessageLength_over250chars_returnsFailureWithCount() {
        String longText = "A".repeat(260);
        String result   = message1.checkMessageLength(longText);
        assertEquals("Message exceeds 250 characters by 10, please reduce size.", result);
    }

    @Test
    public void testCheckMessageLength_exactlyAtLimit_returnsSuccess() {
        String exactText = "A".repeat(250);
        String result    = message1.checkMessageLength(exactText);
        assertEquals("Message ready to send.", result);
    }

    @Test
    public void testCheckMessageLength_oneOver_returnsFailureWithCountOf1() {
        String oneOverText = "A".repeat(251);
        String result      = message1.checkMessageLength(oneOverText);
        assertEquals("Message exceeds 250 characters by 1, please reduce size.", result);
    }

    // ── Recipient cell number ─────────────────────

    @Test
    public void testCheckRecipientCell_validNumber_returnsSuccess() {
        String result = message1.checkRecipientCell(message1.getRecipient());
        assertEquals("Cell phone number successfully captured.", result);
    }

    @Test
    public void testCheckRecipientCell_invalidNumber_returnsFailure() {
        String result = message2.checkRecipientCell(message2.getRecipient());
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code.", result);
    }

    // ── Hash ──────────────────────────────────────

    @Test
    public void testCreateMessageHash_correctFormat_endsWithExpectedWords() {
        String hash = message1.createMessageHash();
        assertTrue("Hash should end with :0:HITONIGHT", hash.endsWith(":0:HITONIGHT"));
    }

    @Test
    public void testCreateMessageHash_isUppercase() {
        String hash = message1.createMessageHash();
        assertEquals("Hash must be fully uppercase", hash.toUpperCase(), hash);
    }

    @Test
    public void testCreateMessageHash_multipleMessages_loopTest() {
        String[] texts = {
            "Hi Mike, can you join us for dinner tonight?",
            "Hi Keegan, did you receive the payment?"
        };
        String[] expectedEndings = { "HITONIGHT", "HIPAYMENT" };

        for (int i = 0; i < texts.length; i++) {
            Message msg = new Message(i + 1);
            msg.setRecipient("+27718693002");
            msg.setMessageText(texts[i]);
            String hash = msg.createMessageHash();
            assertTrue(
                "Hash for message " + (i + 1) + " should contain " + expectedEndings[i],
                hash.contains(expectedEndings[i])
            );
        }
    }

    // ── Message ID ────────────────────────────────

    @Test
    public void testCheckMessageID_generatedID_isNotNull() {
        assertNotNull("Message ID should not be null", message1.getMessageID());
    }

    @Test
    public void testCheckMessageID_generatedID_isExactly10Chars() {
        assertTrue("Message ID should be 10 characters or fewer", message1.checkMessageID());
    }

    // ── sentMessage actions ───────────────────────

    @Test
    public void testSentMessage_userSelectsSend_returnsCorrectString() {
        TestableMessage msg = new TestableMessage(1, 1);
        msg.setRecipient("+27718693002");
        msg.setMessageText("Hi Mike, can you join us for dinner tonight?");
        msg.createMessageHash();
        assertEquals("Message successfully sent.", msg.sentMessage());
    }

    @Test
    public void testSentMessage_userSelectsDisregard_returnsCorrectString() {
        TestableMessage msg = new TestableMessage(1, 2);
        msg.setRecipient("+27718693002");
        msg.setMessageText("Hi Mike, can you join us for dinner tonight?");
        msg.createMessageHash();
        assertEquals("Press 0 to delete the message.", msg.sentMessage());
    }

    @Test
    public void testSentMessage_userSelectsStore_returnsCorrectString() {
        TestableMessage msg = new TestableMessage(1, 3);
        msg.setRecipient("+27718693002");
        msg.setMessageText("Hi Mike, can you join us for dinner tonight?");
        msg.createMessageHash();
        assertEquals("Message successfully stored.", msg.sentMessage());
    }

    // ══════════════════════════════════════════════
    // ── PART 3 TESTS ──────────────────────────────
    // ══════════════════════════════════════════════

    // ── Test 1: Sent messages array correctly populated ──

    /**
     * Process messages 1 and 4 as Sent and verify that the sentMessages
     * array contains both expected texts.
     * POE expected values: "Did you get the cake?" and "It is dinner time!"
     */
    @Test
    public void testSentMessagesArray_correctlyPopulated() {
        // ARRANGE – message 1 (Sent)
        TestableMessage msg1 = new TestableMessage(1, 1);
        msg1.setRecipient("+27834557896");
        msg1.setMessageText("Did you get the cake?");
        msg1.createMessageHash();

        // ARRANGE – message 4 (Sent)
        TestableMessage msg4 = new TestableMessage(4, 1);
        msg4.setRecipient("0838884567");
        msg4.setMessageText("It is dinner time!");
        msg4.createMessageHash();

        // ACT – calling sentMessage() populates sentMessages via processMessageAction()
        msg1.sentMessage();
        msg4.sentMessage();

        // ASSERT
        assertEquals("Did you get the cake?", Message.getSentMessages().get(0));
        assertTrue("Sent array should contain 'It is dinner time!'",
                   Message.getSentMessages().contains("It is dinner time!"));
    }

    // ── Test 2: Display longest message ──

    /**
     * Populate storedMessages with the POE Part 3 data and verify that
     * displayLongestMessage() returns the correct longest message.
     * POE expected: "Where are you? You are late! I have asked you to be on time."
     */
    @Test
    public void testDisplayLongestMessage_returnsCorrectMessage() {
        // ARRANGE – add Part 3 stored message texts directly
        Message.addToStoredMessages("Did you get the cake?");
        Message.addToStoredMessages("Where are you? You are late! I have asked you to be on time.");
        Message.addToStoredMessages("How are you doing?");
        Message.addToStoredMessages("It is dinner time!");
        Message.addToStoredMessages("Ok, I am leaving without you.");

        // ACT
        String longest = new Message(1).displayLongestMessage();

        // ASSERT
        assertEquals(
            "Where are you? You are late! I have asked you to be on time.",
            longest
        );
    }

    // ── Test 3: Search by message ID ──

    /**
     * Send message 4 with a known predictable ID, then search for that ID
     * and verify the correct message text is returned.
     * POE expected return: "It is dinner time!"
     */
    @Test
    public void testSearchByMessageID_returnsCorrectMessage() {
        // ARRANGE – use a known ID so the test is deterministic
        TestableMessage msg4 = new TestableMessage(4, 1);
        msg4.setRecipient("0838884567");
        msg4.setMessageText("It is dinner time!");
        msg4.setMessageID("TEST000004");   // predictable ID for this test
        msg4.createMessageHash();
        msg4.sentMessage();   // adds to sentMessages and messageIDs

        // ACT
        String result = new Message(1).searchByMessageID("TEST000004");

        // ASSERT
        assertEquals("It is dinner time!", result);
    }

    // ── Test 4: Search by recipient ──

    /**
     * Send two messages to +27838884567 (messages 2 and 5) and verify that
     * searchByRecipient() returns both message texts.
     * POE expected: both "Where are you? You are late! I have asked you to be on time."
     *               and "Ok, I am leaving without you."
     */
    @Test
    public void testSearchByRecipient_returnsAllMatchingMessages() {
        // ARRANGE – message 2 (Sent to +27838884567)
        TestableMessage msg2 = new TestableMessage(2, 1);
        msg2.setRecipient("+27838884567");
        msg2.setMessageText("Where are you? You are late! I have asked you to be on time.");
        msg2.createMessageHash();
        msg2.sentMessage();

        // ARRANGE – message 5 (Sent to same recipient)
        TestableMessage msg5 = new TestableMessage(5, 1);
        msg5.setRecipient("+27838884567");
        msg5.setMessageText("Ok, I am leaving without you.");
        msg5.createMessageHash();
        msg5.sentMessage();

        // ACT
        String result = new Message(1).searchByRecipient("+27838884567");

        // ASSERT – result must contain both messages
        assertTrue("Result should contain message 2 text",
                   result.contains("Where are you? You are late! I have asked you to be on time."));
        assertTrue("Result should contain message 5 text",
                   result.contains("Ok, I am leaving without you."));
    }

    // ── Test 5: Delete by message hash ──

    /**
     * Send message 2, capture its hash, then delete by that hash and verify
     * the success message.
     * POE expected: "Message: Where are you? You are late! I have asked you to be on time. successfully deleted."
     */
    @Test
    public void testDeleteByHash_removesCorrectMessage() {
        // ARRANGE – send message 2 and capture the hash
        TestableMessage msg2 = new TestableMessage(2, 1);
        msg2.setRecipient("+27838884567");
        msg2.setMessageText("Where are you? You are late! I have asked you to be on time.");
        String hash = msg2.createMessageHash();   // capture before sending
        msg2.sentMessage();                       // populates arrays

        // ACT
        String result = new Message(1).deleteByHash(hash);

        // ASSERT
        assertEquals(
            "Message: Where are you? You are late! I have asked you to be on time. successfully deleted.",
            result
        );
    }

    // ── Test 6: Display report contains required fields ──

    /**
     * Send messages 1 and 4, then verify that printMessages() returns a String
     * containing the hash, recipient, and message text for all sent messages.
     */
    @Test
    public void testDisplayReport_containsRequiredFields() {
        // ARRANGE – send message 1
        TestableMessage msg1 = new TestableMessage(1, 1);
        msg1.setRecipient("+27834557896");
        msg1.setMessageText("Did you get the cake?");
        String hash1 = msg1.createMessageHash();
        msg1.sentMessage();

        // ARRANGE – send message 4
        TestableMessage msg4 = new TestableMessage(4, 1);
        msg4.setRecipient("0838884567");
        msg4.setMessageText("It is dinner time!");
        String hash4 = msg4.createMessageHash();
        msg4.sentMessage();

        // ACT
        String report = Message.printMessages();

        // ASSERT – report must contain hash, recipient, and text for each message
        assertTrue("Report should contain hash for message 1",  report.contains(hash1));
        assertTrue("Report should contain hash for message 4",  report.contains(hash4));
        assertTrue("Report should contain recipient +27834557896", report.contains("+27834557896"));
        assertTrue("Report should contain recipient 0838884567",   report.contains("0838884567"));
        assertTrue("Report should contain 'Did you get the cake?'", report.contains("Did you get the cake?"));
        assertTrue("Report should contain 'It is dinner time!'",    report.contains("It is dinner time!"));
    }
}
