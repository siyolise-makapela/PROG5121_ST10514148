import java.io.*;
import java.util.*;
import org.json.JSONObject;

/**
 * Message.java
 * Represents a single chat message in the ChatApp.
 */
public class Message {

    // ── INSTANCE FIELDS ──────────────────────────────────────────────────────
    private int    messageNumber;
    private String recipient;
    private String messageText;
    private String messageID;
    private String messageHash;

    // ── STATIC PARALLEL ARRAYS ───────────────────────────────────────────────
    private static List<String> sentMessages        = new ArrayList<>();
    private static List<String> disregardedMessages = new ArrayList<>();
    private static List<String> storedMessages      = new ArrayList<>();
    private static List<String> messageHashes       = new ArrayList<>();
    private static List<String> messageIDs          = new ArrayList<>();
    private static List<String> recipientList       = new ArrayList<>();

    // ── CONSTRUCTORS ─────────────────────────────────────────────────────────
    public Message(int messageNumber) {
        this.messageNumber = messageNumber;
        this.messageID     = generateMessageID();
    }

    public Message() {
        this.messageID = generateMessageID();
    }

    // ── PRIVATE HELPERS ──────────────────────────────────────────────────────
    private String generateMessageID() {
        String chars  = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            sb.append(chars.charAt(random.nextInt(chars.length())));
        }
        return sb.toString();
    }

    // ── GETTERS / SETTERS ────────────────────────────────────────────────────
    public int    getMessageNumber()             { return messageNumber; }
    public void   setMessageNumber(int n)        { this.messageNumber = n; }
    public String getRecipient()                 { return recipient; }
    public void   setRecipient(String recipient) { this.recipient = recipient; }
    public String getMessageText()               { return messageText; }
    public void   setMessageText(String text)    { this.messageText = text; }
    public String getMessageID()                 { return messageID; }
    public void   setMessageID(String id)        { this.messageID = id; }
    public String getMessageHash()               { return messageHash; }

    // ── STATIC ARRAY ACCESSORS ───────────────────────────────────────────────
    public static List<String> getSentMessages()        { return sentMessages; }
    public static List<String> getDisregardedMessages() { return disregardedMessages; }
    public static List<String> getStoredMessages()      { return storedMessages; }
    public static List<String> getMessageHashes()       { return messageHashes; }
    public static List<String> getMessageIDs()          { return messageIDs; }
    public static List<String> getRecipientList()       { return recipientList; }

    public static void clearAllArrays() {
        sentMessages.clear();
        disregardedMessages.clear();
        storedMessages.clear();
        messageHashes.clear();
        messageIDs.clear();
        recipientList.clear();
    }

    public static void addToStoredMessages(String message) {
        storedMessages.add(message);
    }

    // ── VALIDATION ───────────────────────────────────────────────────────────
    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    public String checkMessageLength(String messageText) {
        final int LIMIT = 250;
        if (messageText.length() <= LIMIT) {
            return "Message ready to send.";
        }
        int excess = messageText.length() - LIMIT;
        return "Message exceeds 250 characters by " + excess + ", please reduce size.";
    }

    public String checkRecipientCell(String cellNumber) {
        return Login.checkCellPhoneNumber(cellNumber);
    }

    // ── HASH GENERATION ──────────────────────────────────────────────────────
    /**
     * FIX: original used (messageNumber - 1) which gives -1 when messageNumber == 0
     * (no-arg constructor).  Now uses Math.max(0, messageNumber - 1) so the index
     * is never negative.
     */
    public String createMessageHash() {
        String[] words   = messageText.trim().split("\\s+");
        String firstWord = words[0].replaceAll("[^a-zA-Z]", "").toUpperCase();
        String lastWord  = words[words.length - 1].replaceAll("[^a-zA-Z]", "").toUpperCase();
        // FIX: guard against negative index when messageNumber is 0
        int messageIndex = Math.max(0, messageNumber - 1);
        this.messageHash = (messageID + ":" + messageIndex + ":" + firstWord + lastWord).toUpperCase();
        return this.messageHash;
    }

    // ── ARRAY POPULATION ────────────────────────────────────────────────────
    protected void processMessageAction(int option) {
        if (messageHash == null) {
            createMessageHash();
        }
        switch (option) {
            case 1: // Send
                sentMessages.add(messageText);
                messageHashes.add(messageHash);
                messageIDs.add(messageID);
                recipientList.add(recipient);
                break;
            case 2: // Disregard
                disregardedMessages.add(messageText);
                break;
            case 3: // Store
                writeMessageToJson();
                // FIX: stored messages were never added to sentMessages, so
                // searchByMessageID / deleteByHash would crash on them.
                // We add to sentMessages so all parallel arrays stay in sync.
                sentMessages.add(messageText);
                messageHashes.add(messageHash);
                messageIDs.add(messageID);
                recipientList.add(recipient);
                break;
            default:
                break;
        }
    }

    // ── sentMessage ──────────────────────────────────────────────────────────
    public String sentMessage() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\nWhat would you like to do with your message?");
        System.out.println("1. Send");
        System.out.println("2. Disregard");
        System.out.println("3. Store");
        System.out.print("Enter option: ");

        // FIX: original called scanner.nextInt() which leaves a newline in the
        // buffer, causing the next scanner.nextLine() in Main.java to read "".
        // Using nextLine() + parseInt() keeps the buffer clean.
        int option;
        try {
            option = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            return "Invalid option selected.";
        }

        processMessageAction(option);

        switch (option) {
            case 1:  return "Message successfully sent.";
            case 2:  return "Press 0 to delete the message.";
            case 3:  return "Message successfully stored.";
            default: return "Invalid option selected.";
        }
    }

    // ── JSON WRITE ───────────────────────────────────────────────────────────
    private void writeMessageToJson() {
        // Attribution: org.json - https://mvnrepository.com/artifact/org.json/json
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("messages.json", true))) {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("messageHash", messageHash);
            jsonObject.put("messageID",   messageID);
            jsonObject.put("recipient",   recipient);
            jsonObject.put("messageText", messageText);
            writer.write(jsonObject.toString());
            writer.newLine();
        } catch (IOException e) {
            System.out.println("Error writing message to file: " + e.getMessage());
        }
    }

    // ── JSON READ ────────────────────────────────────────────────────────────
    public static void loadStoredMessages() {
        File file = new File("messages.json");
        if (!file.exists()) return;
        // Attribution: org.json - https://mvnrepository.com/artifact/org.json/json
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(line);
                    String text = jsonObject.optString("messageText", "");
                    if (!text.isEmpty()) {
                        storedMessages.add(text);
                    }
                }
            }
            System.out.println("Stored messages loaded: " + storedMessages.size());
        } catch (IOException e) {
            System.out.println("No stored messages file found – starting fresh.");
        }
    }

    // ── DISPLAY LONGEST MESSAGE ──────────────────────────────────────────────
    public String displayLongestMessage() {
        String longest = "";
        for (String msg : storedMessages) {
            if (msg.length() > longest.length()) {
                longest = msg;
            }
        }
        return longest;
    }

    // ── SEARCH BY MESSAGE ID ─────────────────────────────────────────────────
    public String searchByMessageID(String id) {
        for (int i = 0; i < messageIDs.size(); i++) {
            if (messageIDs.get(i).equals(id)) {
                return sentMessages.get(i);
            }
        }
        return "Message not found.";
    }

    // ── SEARCH BY RECIPIENT ──────────────────────────────────────────────────
    public String searchByRecipient(String recipient) {
        StringBuilder results = new StringBuilder();
        for (int i = 0; i < recipientList.size(); i++) {
            if (recipientList.get(i).equals(recipient)) {
                results.append(sentMessages.get(i)).append("\n");
            }
        }
        if (results.length() == 0) {
            return "No messages found for recipient.";
        }
        return results.toString().trim();
    }

    // ── DELETE BY HASH ───────────────────────────────────────────────────────
    /**
     * FIX: original removed from sentMessages using the hash index, but for
     * stored messages sentMessages had no entry at that index, causing
     * IndexOutOfBoundsException.  Now all four arrays are kept in sync
     * (see processMessageAction case 3 fix), so the removal is always safe.
     */
    public String deleteByHash(String hash) {
        for (int i = 0; i < messageHashes.size(); i++) {
            if (messageHashes.get(i).equals(hash)) {
                String deletedText = (i < sentMessages.size()) ? sentMessages.get(i) : "Unknown";
                messageHashes.remove(i);
                if (i < sentMessages.size())  sentMessages.remove(i);
                if (i < messageIDs.size())    messageIDs.remove(i);
                if (i < recipientList.size()) recipientList.remove(i);
                return "Message: " + deletedText + " successfully deleted.";
            }
        }
        return "Hash not found.";
    }

    // ── PRINT REPORT ─────────────────────────────────────────────────────────
    public static String printMessages() {
        StringBuilder report = new StringBuilder();
        report.append("=== Message Report ===\n");
        if (sentMessages.isEmpty()) {
            report.append("No messages sent yet.\n");
            return report.toString();
        }
        for (int i = 0; i < sentMessages.size(); i++) {
            report.append("---------------------\n");
            report.append("Hash      : ")
                  .append(i < messageHashes.size() ? messageHashes.get(i) : "N/A").append("\n");
            report.append("Recipient : ")
                  .append(i < recipientList.size() ? recipientList.get(i) : "N/A").append("\n");
            report.append("Message   : ")
                  .append(sentMessages.get(i)).append("\n");
        }
        return report.toString();
    }

    // ── PRINT MESSAGE DETAILS ────────────────────────────────────────────────
    public void printMessageDetails() {
        System.out.println("\n--- Message Details ---");
        System.out.println("Message Number : " + messageNumber);
        System.out.println("Message ID     : " + messageID);
        System.out.println("Recipient      : " + recipient);
        System.out.println("Message Text   : " + messageText);
        System.out.println("Message Hash   : " + (messageHash != null ? messageHash : "Not yet generated"));
        System.out.println("-----------------------");
    }
}
