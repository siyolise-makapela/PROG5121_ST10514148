public class Login {
    String username;
    String password;
    String phoneNumber;
    String firstName;
    String lastName;

    public Login() {}

    public Login(String username, String password, String firstName, String lastName, String cellNumber) {
        this.username    = username;
        this.password    = password;
        this.firstName   = firstName;
        this.lastName    = lastName;
        this.phoneNumber = cellNumber;
    }

    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    public boolean checkPasswordComplexity(String password) {
        boolean hasCapital = false;
        boolean hasNumber  = false;
        boolean hasSpecial = false;
        for (int i = 0; i < password.length(); i++) {
            char c = password.charAt(i);
            if (Character.isUpperCase(c))        hasCapital = true;
            else if (Character.isDigit(c))       hasNumber  = true;
            else if (!Character.isLetterOrDigit(c)) hasSpecial = true;
        }
        return password.length() >= 8 && hasCapital && hasNumber && hasSpecial;
    }

    // FIX 1: was an instance method – Message.java calls it as Login.checkCellPhoneNumber(...)
    // so it MUST be static.
    // FIX 2: was returning boolean – Message/Main both expect a String result message.
    // FIX 3: length check was <= 12 but "+27" (3) + 9 digits = 12 chars, so <= 12 is correct;
    //         however the original also never checked that the remainder was all digits.
    //         Added digit check for correctness.
    public static String checkCellPhoneNumber(String phone) {
        if (phone != null && phone.startsWith("+27") && phone.length() == 12) {
            String digits = phone.substring(3);
            boolean allDigits = true;
            for (char c : digits.toCharArray()) {
                if (!Character.isDigit(c)) { allDigits = false; break; }
            }
            if (allDigits) return "Cell phone number successfully captured.";
        }
        return "Cell phone number incorrectly formatted or does not contain international code.";
    }

    // FIX 4: registerUser() in Main.java is called as login.registerUser(username, password)
    // with only 2 args – but original had 3 params. Added overload that uses stored phoneNumber.
    public String registerUser(String username, String password) {
        if (!checkUserName(username)) {
            return "Username is not correctly formatted, please ensure that your username "
                 + "contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted, please ensure that the password "
                 + "contains at least eight characters, a capital letter, a number and a special character.";
        }
        this.username = username;
        this.password = password;
        return "Registration successful.";
    }

    // Keep 3-arg version for any direct calls
    public String registerUser(String username, String password, String phoneNumber) {
        this.phoneNumber = phoneNumber;
        return registerUser(username, password);
    }

    // FIX 5: loginUser() in Main.java expects a String return ("Welcome..." or error).
    // Original returned boolean; renamed that to loginCheck() and made loginUser() return String.
    public boolean loginCheck(String loginUsername, String loginPassword) {
        return loginUsername.equals(this.username) && loginPassword.equals(this.password);
    }

    public String loginUser(String loginUsername, String loginPassword) {
        if (loginCheck(loginUsername, loginPassword)) {
            return "Welcome " + firstName + ", it is great to see you again.";
        }
        return "Username or password incorrect, please try again.";
    }

    public String returnLoginStatus(boolean loggedIn) {
        if (loggedIn) return "Welcome " + this.username + ", it is great to see you again.";
        return "Username or password incorrect, please try again.";
    }
}
