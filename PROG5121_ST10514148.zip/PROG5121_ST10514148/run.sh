#!/bin/bash
# ── Mac/Linux build & run script for QuickChat ────────────────────────────
# Place this file in the same folder as Login.java, Message.java, Main.java
# and the org.json jar (json-20240303.jar).
#
# Download the jar from:
#   https://repo1.maven.org/maven2/org/json/json/20240303/json-20240303.jar
#
# Make this script executable once:  chmod +x run.sh
# Then run it with:                  ./run.sh

echo "Compiling QuickChat..."
javac -cp .:json-20240303.jar Login.java Message.java Main.java

if [ $? -ne 0 ]; then
    echo ""
    echo "Compilation FAILED. Make sure json-20240303.jar is in this folder."
    exit 1
fi

echo ""
echo "Compilation successful. Starting QuickChat..."
echo "─────────────────────────────────────────────"
java -cp .:json-20240303.jar Main
