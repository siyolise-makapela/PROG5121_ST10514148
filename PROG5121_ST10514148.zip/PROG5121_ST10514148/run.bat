@echo off
REM ── Windows build & run script for QuickChat ──────────────────────────────
REM Place this file in the same folder as Login.java, Message.java, Main.java
REM and the org.json jar (json-20240303.jar).
REM
REM Download the jar from:
REM   https://repo1.maven.org/maven2/org/json/json/20240303/json-20240303.jar

echo Compiling QuickChat...
javac -cp .;json-20240303.jar Login.java Message.java Main.java

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Compilation FAILED. Make sure json-20240303.jar is in this folder.
    pause
    exit /b 1
)

echo.
echo Compilation successful. Starting QuickChat...
echo ─────────────────────────────────────────────
java -cp .;json-20240303.jar Main
pause
